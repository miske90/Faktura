﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fakturisanje
{
    public partial class GlavnaFormacs : Form
    {
        public GlavnaFormacs()
        {
            InitializeComponent();
        }

        private void GlavnaFormacs_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void pregledFakturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PregledFaktura pre = new PregledFaktura();
            pre.MdiParent = this;
            pre.StartPosition = FormStartPosition.CenterScreen; 
            pre.Show();
        }

        private void dokumentFakturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DokumentFaktura dok = new DokumentFaktura();
            dok.MdiParent = this;
            dok.StartPosition = FormStartPosition.CenterScreen;
            dok.Show();
        }

        private void stavkaFaktureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StavkaFakture stavka = new StavkaFakture();
            stavka.MdiParent = this;
            stavka.StartPosition = FormStartPosition.CenterScreen;
            stavka.Show();
        }
    }
}
