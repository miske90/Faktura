﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fakturisanje
{
    public partial class DokumentFaktura : Form
    {
        public DokumentFaktura()
        {
            InitializeComponent();
        }

        private void DokumentFaktura_Load(object sender, EventArgs e)
        {
            this.ActiveControl = dateTimePicker1;
            LoadData();
        }

        private void dateTimePicker1_KeyDown(object sender, KeyEventArgs e)
        {
          if(e.KeyCode== Keys.Enter)
            {
                textBox1.Focus();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if(textBox1.Text.Length > 0)
                {
                    textBox2.Focus();
                }
                else
                {
                    textBox1.Focus();
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            } 
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void ResetRecord()
        {
            dateTimePicker1.Value = DateTime.Now;
            textBox1.Clear();
            textBox2.Clear();
            BtnAdd.Text = "Add";
            dateTimePicker1.Focus();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            ResetRecord();
        }

        private bool ifDokumentFakturaExists(SqlConnection con,string BrojDokumenta)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [DokumentFaktura] Where [Broj dokumenta]='"+BrojDokumenta+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            con.Open();

            var sqlQuery = "";
            if (ifDokumentFakturaExists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [DokumentFaktura] SET [Ukupno] = '" + textBox2.Text + "' WHERE [Broj dokumenta] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[DokumentFaktura] ([Broj dokumenta],[Datum dokumenta],[Ukupno])  VALUES
             ('" + textBox1.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox2.Text + "')";
            }
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Records save Successfully!");
            ResetRecord();
        }

        private void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM [DokumentFaktura]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvDokument.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dgvDokument.Rows.Add();
                dgvDokument.Rows[n].Cells[0].Value = item["Broj dokumenta"].ToString();
                dgvDokument.Rows[n].Cells[1].Value = item["Datum dokumenta"].ToString();
                dgvDokument.Rows[n].Cells[2].Value = item["Ukupno"].ToString();
            }
        }

        private void dgvDokument_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            BtnAdd.Text = "Update";
            textBox1.Text = dgvDokument.SelectedRows[0].Cells[0].Value.ToString();
            dateTimePicker1.Text = dgvDokument.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dgvDokument.SelectedRows[0].Cells[2].Value.ToString();
            
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            var sqlQuery = "";
            if (ifDokumentFakturaExists(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [DokumentFaktura] WHERE [Broj dokumenta] = '" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Delete Successfully!");
            }
            else
            {
                MessageBox.Show("Record not exists..!");
            }
            LoadData();
            ResetRecord();
        }
    }

}
