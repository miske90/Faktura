﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fakturisanje
{
    public partial class PregledFaktura : Form
    {
        public PregledFaktura()
        {
            InitializeComponent();
        }

        private void PregledFaktura_Load(object sender, EventArgs e)
        {
            this.ActiveControl = dateTimePicker1;
            LoadData();
        }

        private void dateTimePicker1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox1.Focus();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox1.Text.Length > 0)
                {
                    textBox2.Focus();
                }
                else
                {
                    textBox1.Focus();
                }
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox2.Text.Length > 0)
                {
                    BtnAdd.Focus();
                }
                else
                {
                    textBox2.Focus();
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void ResetRecords()
        {
            dateTimePicker1.Value = DateTime.Now;
            textBox1.Clear();
            textBox2.Clear();
            BtnAdd.Text = "Add";
            dateTimePicker1.Focus();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            ResetRecords();
        }

        private bool IfFakturaExists(SqlConnection con, string BrojFakture)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 FROM [PregledFaktura] where [Broj fakture]= '" + BrojFakture + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM [PregledFaktura]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            var sqlQuery = "";
            if (IfFakturaExists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [PregledFaktura] SET [Ukupno] = '" + textBox2.Text + "' WHERE [Broj fakture] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO PregledFaktura ([Broj fakture],[Datum fakture],[Ukupno])  VALUES
             ('" + textBox1.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox2.Text + "')";
            }
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Record save Successfully!");
            ResetRecords();

        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM [PregledFaktura]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvPregled.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dgvPregled.Rows.Add();
                dgvPregled.Rows[n].Cells["dgBrFakture"].Value = item["Broj fakture"].ToString();
                dgvPregled.Rows[n].Cells["dgUkupno"].Value = item["Ukupno"].ToString();
                dgvPregled.Rows[n].Cells["dgDatumfakture"].Value = item["Datum fakture"].ToString();
            }
        }

        private void dgvPregled_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            BtnAdd.Text = "Update";
            textBox1.Text = dgvPregled.SelectedRows[0].Cells["dgBrFakture"].Value.ToString();
            textBox2.Text = dgvPregled.SelectedRows[0].Cells["dgUkupno"].Value.ToString();
            dateTimePicker1.Text = dgvPregled.SelectedRows[0].Cells["dgDatumfakture"].Value.ToString();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            var sqlQuery = "";
            if (IfFakturaExists(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [PregledFaktura] WHERE [Broj fakture] = '" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record delete successfully!!");
            }
            else
            {
                MessageBox.Show("Record not exists..!");
            }
            LoadData();
            ResetRecords();
        }
    }
}
