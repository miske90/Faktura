﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fakturisanje
{
    public partial class StavkaFakture : Form
    {
        public StavkaFakture()
        {
            InitializeComponent();
        }

        private void StavkaFakture_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if(textBox2.Text.Length > 0)
                {
                    textBox3.Focus();
                }
                else
                {
                    textBox2.Focus();
                }
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (textBox3.Text.Length > 0)
            {
                textBox4.Focus();
            }
            else
            {
                textBox3.Focus();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (textBox4.Text.Length > 0)
            {
                BtnAdd.Focus();
            }
            else
            {
                textBox4.Focus();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void ResetRecord()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            BtnAdd.Text = "Add";
            textBox1.Focus();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            ResetRecord();
        }

        private bool ifStavkaFaktureExists(SqlConnection con, string RedniBroj)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [StavkaFakture] Where [Redni broj]='" + RedniBroj + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            con.Open();

            var sqlQuery = "";
            if (ifStavkaFaktureExists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [StavkaFakture] SET [Kolicina] = '" +textBox2.Text + "',[Cena]='"+textBox3.Text+"',[Ukupno] = '" + textBox4.Text + "' WHERE [Redni broj] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].StavkaFakture ([Redni broj],[Kolicina],[Cena],[Ukupno])  VALUES
             ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','"+textBox4.Text+"')";
            }
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Records save Successfully!");
            ResetRecord();
        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM [StavkaFakture]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvFakture.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dgvFakture.Rows.Add();
                dgvFakture.Rows[n].Cells[0].Value = item["Redni broj"].ToString();
                dgvFakture.Rows[n].Cells[1].Value = item["Kolicina"].ToString();
                dgvFakture.Rows[n].Cells[2].Value = item["Cena"].ToString();
                dgvFakture.Rows[n].Cells[3].Value = item["Ukupno"].ToString();
            }
        }

        private void dgvFakture_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            BtnAdd.Text = "Update";
            textBox1.Text = dgvFakture.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dgvFakture.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dgvFakture.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dgvFakture.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=korisnik-pc;Initial Catalog=Fakturisanje;Integrated Security=True");
            var sqlQuery = "";
            if (ifStavkaFaktureExists(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [StavkaFakture] WHERE [Redni broj] = '" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Delete Successfully!");
            }
            else
            {
                MessageBox.Show("Record not exists..!");
            }
            LoadData();
            ResetRecord();
        }

       
    }
}
